// file bs.c

#include "print.h"

int main() {
    printIt("Betriebssysteme, was sonst :-)");
}

