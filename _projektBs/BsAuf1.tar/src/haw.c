// file haw.c

#include "print.h"

int main() {
   printIt("HAW Hamburg");
}

