// file print.h

#ifndef _PRINT_H
#define _PRINT_H

extern void printIt(char *s);

#endif /* _PRINT_H */

