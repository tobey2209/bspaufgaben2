// file hallo.c

#include "print.h"

int main() {
   printIt("Hallo");
}

